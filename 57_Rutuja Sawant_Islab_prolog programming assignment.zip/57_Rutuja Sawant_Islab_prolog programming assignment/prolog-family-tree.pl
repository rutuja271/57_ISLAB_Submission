/* Facts */
male(Alan).
male(Dan).
male(Walter).
male(Tom).
male(John).
female(Emma).
female(helen).
female(martha).
female(liz).
female(Nina).
feamale(katy)

parent_of(Alan,Walter).
parent_of(Alan,Liz).
parent_of(Emma,Walter).
parent_of(Emma,Liz).
parent_of(Martha,Nina).
parent_of(Martha,Katy).
parent_of(Walter,Nina).
parent_of(Walter,Katy).
parent_of(Dan,Tom).
parent_of(Helen, Tom).
parent_of(Liz,John).
parent_of(Tom,John).

/* Rules */
father_of(X,Y):- male(X),
    parent_of(X,Y).
 
mother_of(X,Y):- female(X),
    parent_of(X,Y).
 
grandfather_of(X,Y):- male(X),
    parent_of(X,Z),
    parent_of(Z,Y).
 
grandmother_of(X,Y):- female(X),
    parent_of(X,Z),
    parent_of(Z,Y).
 
sister_of(X,Y):- %(X,Y or Y,X)%
    female(X),
    father_of(F, Y), father_of(F,X),X \= Y.
 
sister_of(X,Y):- female(X),
    mother_of(M, Y), mother_of(M,X),X \= Y.
 
aunt_of(X,Y):- female(X),
    parent_of(Z,Y), sister_of(Z,X),!.
 
brother_of(X,Y):- %(X,Y or Y,X)%
    male(X),
    father_of(F, Y), father_of(F,X),X \= Y.
 
brother_of(X,Y):- male(X),
    mother_of(M, Y), mother_of(M,X),X \= Y.
 
uncle_of(X,Y):-
    parent_of(Z,Y), brother_of(Z,X).

ancestor_of(X,Y):- parent_of(X,Y).
ancestor_of(X,Y):- parent_of(X,Z),
    ancestor_of(Z,Y).